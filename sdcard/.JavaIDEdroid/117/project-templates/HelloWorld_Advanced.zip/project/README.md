1. Extract `.zip` file to your main project directory.
2. Change value of `projectName` to name of your project name and value of `projectPath` to path of your Java Android sub project in `project\Statically Recompiler.bsh`.
3. Execute `project\Statically Recompiler.bsh` directly on JavaIDEdroid or choose this file in JavaIDEdroid as Beanshell Script.
4. Touch play button in "BEANSHELL" tab for compiling android java project.